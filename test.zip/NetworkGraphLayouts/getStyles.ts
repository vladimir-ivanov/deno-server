export const noLabelClass = 'noLabel';
export const outlinedLabelClass = 'outlinedLabel';
