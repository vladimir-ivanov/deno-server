import { useCallback, useEffect, useRef } from 'react';
import cytoscape, { CollectionData, ElementDefinition } from 'cytoscape';
import { range } from 'lodash';
import L, { LatLngBoundsLiteral } from 'leaflet';
import { CytoscapeLeaf } from '../@types/cytoscape-leaf';
import { layoutConfigs } from '../NetworkGraphLayouts';
import { CytoscapeEvent } from '../types';
import { detectNodesCollision } from './detectNodesCollision';
import { outlinedLabelClass } from './getStyles';

class Coordinates {
  readonly #longitudeRange = [] as number[];

  constructor(numberOfRecords: number) {
    this.#longitudeRange = range(-500, 500, (2 * 500) / (numberOfRecords + 1));
  }

  getNextLongitude = (index: number) => this.#longitudeRange[index];
  getNextLatitude = (index: number) => (index % 2 === 0 ? -83 : 84);
}

interface Props {
  id: string;
  cy?: cytoscape.Core;
  data: ElementDefinition[];
  onInit: (cyLeaf: CytoscapeLeaf) => void;
}

export const useMapRefreshLayout = ({ id, cy, data, onInit }: Props) => {
  const cyLeafRef = useRef<CytoscapeLeaf>();

  const initLeaflet = useCallback(
    (cytoscape: cytoscape.Core) => {
      const cyLeaf = cytoscape.leaflet({
        container: document.getElementById(id) as HTMLElement,
        latitude: 'latitude',
        longitude: 'longitude',
        layout: layoutConfigs.map,
      });

      const layer = L.tileLayer(
        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        {
          attribution: '',
          className: 'map-tiles',
        },
      );

      cyLeaf?.map.removeLayer(cyLeaf?.defaultTileLayer);
      cyLeaf?.map.addLayer(layer);
      onInit(cyLeaf);

      return cyLeaf;
    },
    [id, onInit],
  );

  useEffect(() => {
    cy?.elements().remove();
    cy?.reset();
    const handleZoomPan = () => detectNodesCollision(cy);

    cy?.on(CytoscapeEvent.Pan, handleZoomPan);
    let cyLeaf: CytoscapeLeaf;

    if (cy) {
      cyLeaf = initLeaflet(cy);
      cyLeafRef.current = cyLeaf;
    }

    return () => {
      cy?.off(CytoscapeEvent.Pan, handleZoomPan);
      cyLeaf?.destroy();
    };
  }, [cy, id, initLeaflet, onInit]);

  useEffect(() => {
    const fitHandler = () => {
      cyLeafRef.current?.fit();
    };
    const centerHandler = (ev, selectedNodes: CollectionData[]) => {
      const selected = selectedNodes
        .map(node => {
          const data = node.data();
          return [data.latitude, data.longitude];
        })
        .filter(
          ([latitude, longitude]) =>
            latitude !== undefined && longitude !== undefined,
        );
      if (selected && selected.length > 0) {
        const bounds = new L.LatLngBounds(selected as LatLngBoundsLiteral);
        cyLeafRef.current?.map.fitBounds(bounds, { padding: [10, 10] });
      }
    };

    if (cyLeafRef.current) {
      cy?.elements().remove();
      cy?.off('data');
      cy?.off('add');
      cy?.removeData();
      cy?.reset();

      cy?.on(CytoscapeEvent.Fit, fitHandler);
      cy?.on(CytoscapeEvent.Center, centerHandler);

      if (data && data.length > 0) {
        const coordinates = new Coordinates(data.length);
        const nodes = data
          .filter(item => item.group === 'nodes')
          .map((node, index) => ({
            ...node,
            data: {
              ...node.data,
              latitude:
                node.data.latitude ?? coordinates.getNextLatitude(index),
              longitude:
                node.data.longitude ?? coordinates.getNextLongitude(index),
            },
          }));
        const edges = data.filter(item => item.group === 'edges');
        cy?.add([...nodes, ...edges]);
        cyLeafRef.current?.fit();
      }

      if (cy) {
        cy.nodes().forEach(node => {
          node.addClass(outlinedLabelClass);
        });
        detectNodesCollision(cy);
      }
    }

    return () => {
      cy?.off(CytoscapeEvent.Fit, fitHandler);
      cy?.off(CytoscapeEvent.Center, centerHandler);
    };
  }, [cy, data]);

  return { cyLeaf: cyLeafRef.current };
};
