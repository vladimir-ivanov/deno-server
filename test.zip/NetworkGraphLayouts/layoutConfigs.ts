import './cytoscapeLeaf.scss';
import 'leaflet/dist/leaflet.css';
import ciseLayout from 'cytoscape-cise';
import colaLayout from 'cytoscape-cola';
import cytoscape from 'cytoscape';
import d3ForceLayout from 'cytoscape-d3-force';
import dagreLayout from 'cytoscape-dagre';
import fcoseLayout from 'cytoscape-fcose';
import klayLayout from 'cytoscape-klay';
import spreadLayout from 'cytoscape-spread';
import cytoscapeLeaf from '../cytoscapejsLeaflet';

cytoscape.use(ciseLayout);
cytoscape.use(colaLayout);
cytoscape.use(cytoscapeLeaf);
cytoscape.use(d3ForceLayout);
cytoscape.use(dagreLayout);
cytoscape.use(fcoseLayout);
cytoscape.use(klayLayout);
cytoscape.use(spreadLayout);

const commonConfig = {
  nodeDimensionsIncludeLabels: true,
  fit: true,
  padding: 30,
  animate: true,
  animationDuration: 200,
  maxSimulationTime: 2000,
};

const map = {
  name: 'preset' as const,
  fit: false,
};

const spread = {
  ...commonConfig,
  minDist: 60,
};

// defaults to grid if no x, y
const preset = {
  name: 'grid',
  animate: false,
  fit: false,
  transform: function (node, position) {
    const data = node.data();
    const { x, y } = data;
    if (x !== undefined && y !== undefined) {
      return { x, y };
    }
    return position;
  },
};

const cose = {
  ...commonConfig,
  nodeRepulsion: 40000,
  nodeOverlap: 60,
  edgeElasticity: 1000,
  nestingFactor: 5,
  numIter: 10000,
  initialTemp: 2000,
};

const fcose = {
  ...commonConfig,
};

const d3Force = {
  name: 'd3-force',
  ...commonConfig,
  maxIterations: 1000,
  alphaMin: 0.01,
  alphaDecay: 1 - Math.pow(0.001, 1 / 300),
  collideRadius: 10,
  collideStrength: 0.1,
  linkId: element => element.id,
  linkDistance: 150,
  linkIterations: 1,
  manyBodyStrength: -1000,
  manyBodyTheta: 0.9,
  manyBodyDistanceMin: 1,
};

export default {
  circle: commonConfig,
  cola: commonConfig,
  concentric: commonConfig,
  cose,
  d3Force,
  dagre: commonConfig,
  fcose,
  grid: commonConfig,
  klay: commonConfig,
  map,
  preset,
  spread,
};
