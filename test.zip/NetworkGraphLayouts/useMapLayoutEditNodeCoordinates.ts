import { useEffect } from 'react';
import cytoscape from 'cytoscape';
import L from 'leaflet';
import { CytoscapeEvent, MapPosition } from '../types';
import { syncLatLng } from './syncLatLang';

interface Props {
  cy?: cytoscape.Core;
  map?: L.Map;
  onNodeDragEnd: (point: MapPosition) => void;
}

export const useMapLayoutEditNodeCoordinates = ({
  cy,
  map,
  onNodeDragEnd,
}: Props) => {
  useEffect(() => {
    const dragHandler = event => {
      if (map) {
        const node = event.target;
        onNodeDragEnd({
          id: node.data('id'),
          ...syncLatLng(node.position(), map),
        });
      }
    };

    cy?.on(CytoscapeEvent.Dragfree, 'node', dragHandler);

    return () => {
      cy?.off(CytoscapeEvent.Dragfree, 'node', dragHandler);
    };
  }, [cy, map, onNodeDragEnd]);
};
