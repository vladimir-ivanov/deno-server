import L from 'leaflet';

interface NodePosition {
  x: number;
  y: number;
}
export const syncLatLng = ({ x, y }: NodePosition, map: L.Map) => {
  const { lat: latitude, lng: longitude } = map.containerPointToLatLng(
    L.point(x, y),
  );

  return {
    latitude,
    longitude,
  };
};
