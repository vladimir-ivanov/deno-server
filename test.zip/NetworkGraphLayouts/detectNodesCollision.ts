import { NodeSingular } from 'cytoscape';
import { noLabelClass } from './getStyles';

export const detectNodesCollision = (cy?: cytoscape.Core) => {
  const nodes = cy?.nodes();
  nodes?.forEach(node => {
    const { x1, x2, y1, y2 } = node.renderedBoundingBox();

    const intersectingNodeSibling = nodes?.reduce(
      (intersectingNode: null | NodeSingular, sibling) => {
        let noNodeIntersect = true;
        if (sibling !== node) {
          const box = sibling.renderedBoundingBox();

          const noIntersectsY = box.y1 >= y2 || box.y2 <= y1;
          const noIntersectsX = box.x1 >= x2 || box.x2 <= x1;
          noNodeIntersect = noIntersectsY || noIntersectsX;
        }

        if (!noNodeIntersect) {
          return sibling;
        }

        return intersectingNode;
      },
      null,
    );

    if (intersectingNodeSibling) {
      node.addClass(noLabelClass);
      intersectingNodeSibling.addClass(noLabelClass);
    } else {
      node.removeClass(noLabelClass);
    }
  });
};
