import { Box, ContainerColor } from '@trading-applications/ui-components';
import cytoscape, { ElementDefinition } from 'cytoscape';
import { CytoscapeLeaf } from '../@types/cytoscape-leaf';
import { MapViewGraphControls } from '../NetworkGraphControls';
import { MapPosition } from '../types';
import { useMapRefreshLayout } from './useMapRefreshLayout';
import { useMapLayoutEditNodeCoordinates } from './useMapLayoutEditNodeCoordinates';

interface MapGraphLayoutProps {
  id: string;
  cy?: cytoscape.Core;
  data: ElementDefinition[];
  onNodeDragEnd: (position: MapPosition) => void;
  onMapInitialized: (cyLeaf: CytoscapeLeaf) => void;
}

export const MapGraphLayout = ({
  id,
  cy,
  data,
  onNodeDragEnd,
  onMapInitialized,
}: MapGraphLayoutProps) => {
  const mapId = `mapLayout-${id}`;
  const { cyLeaf } = useMapRefreshLayout({
    id: mapId,
    cy,
    data,
    onInit: onMapInitialized,
  });
  useMapLayoutEditNodeCoordinates({
    cy,
    map: cyLeaf?.map,
    onNodeDragEnd,
  });

  return (
    <>
      <Box
        id={mapId}
        zIndex={1}
        overflow="hidden"
        position="absolute"
        top={0}
        left={0}
        right={0}
        bottom={0}
      />
      <Box
        gap="8px"
        position="absolute"
        bottom="204px"
        right="4px"
        zIndex={3}
        bgColor={ContainerColor.CORE_TWO}
        flexDirection="column"
      >
        <MapViewGraphControls cyLeaf={cyLeaf} />
      </Box>
    </>
  );
};
