import { Meta } from '@storybook/react';
import { Box } from '@trading-applications/ui-components';
import { QueryElementTuple, remapQueryNodesAndEdges } from '../../api';
import { NetworkGraph3D } from './NetworkGraph3D';
import data from './testNetworkData.json';

export default {
  title: 'NetworkGraph / NetworkGraph3D',
  component: NetworkGraph3D,
  args: {
    data: remapQueryNodesAndEdges(
      data.results as unknown as QueryElementTuple[],
    ),
  },
} as Meta<typeof NetworkGraph3D>;

const Template = args => (
  <Box height="700px" width="100%" border={5}>
    <NetworkGraph3D {...args} />
  </Box>
);

export const Basic = Template.bind({});
