import { ElementDefinition } from 'cytoscape';

interface GraphData {
  nodes: NodeObject[];
  links: LinkObject[];
}

type NodeObject = object & {
  id?: string | number;
  x?: number;
  y?: number;
  z?: number;
  vx?: number;
  vy?: number;
  vz?: number;
  fx?: number;
  fy?: number;
  fz?: number;
};

type LinkObject = object & {
  source?: string | number | NodeObject;
  target?: string | number | NodeObject;
};

export const remap3DData = (treeData: ElementDefinition[]): GraphData => {
  const links = treeData
    .filter(element => element.group === 'edges')
    .map(element => element.data);

  const nodes = treeData
    .filter(element => element.group === 'nodes')
    .map(element => element.data);

  return {
    nodes,
    links,
  };
};
