import { Box } from '@trading-applications/ui-components';
import ForceGraph3D from '3d-force-graph';
import { useEffect, useMemo, useRef } from 'react';
import SpriteText from 'three-spritetext';
import { NetworkElement } from '../../api';
import { remap3DData } from './remap3DData';

interface ThreeDGraphProps {
  data: NetworkElement[];
}

interface Named {
  name?: string;
}

export const NetworkGraph3D = ({ data }: ThreeDGraphProps) => {
  const graphEl = useRef<HTMLElement>();
  const graphData = useMemo(() => structuredClone(remap3DData(data)), [data]);

  useEffect(() => {
    const graph3D = ForceGraph3D({})
      .nodeColor(node => 'red')
      .nodeLabel((node: Named) => node?.name || '')
      .width(graphEl.current?.getBoundingClientRect().width as number)
      .height(graphEl.current?.getBoundingClientRect().height as number)
      .linkOpacity(0.3)
      .nodeThreeObject(node => {
        const sprite = new SpriteText(node.name);
        sprite.color = 'red';
        sprite.textHeight = 5;
        return sprite;
      });
    if (graphData.nodes.length > 0) {
      graph3D(graphEl.current as HTMLElement).graphData(graphData);
    }
  }, [data, graphData]);

  return <Box ref={graphEl} overflow="hidden" fullHeight fullWidth />;
};
