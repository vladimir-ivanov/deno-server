// Type definitions for cytoscape-leaf 1.2.4
// Project: https://github.com/cytoscape/cytoscape.js-leaflet
// Definitions by: Vladimir Ivanov <https://github.com/vladimir-ivanov>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

import cytoscape = require('cytoscape');
import { GraphElement } from '../../NetworkGraph';

declare const expandCollapse: cytoscape.Ext;
export = expandCollapse;
export as namespace expandCollapse;

declare namespace expandCollapse {
  interface Options {
    /**
     * @default null
     */
    layoutBy?: Layouts | null; // to rearrange after expand/collapse. It's just layout options or whole layout function. Choose your side!
    /**
     * @default true
     */
    fisheye?: boolean;
    /**
     * @default true
     */
    animate?: boolean;
    /**
     * @default 1000
     */
    animationDuration?: number;
    ready?: () => void;
    /**
     * @default true
     */
    undoable?: boolean;
    /**
     * @default true
     */
    cueEnabled?: boolean;
    /**
     * @default top-left
     */
    expandCollapseCuePosition?: string;
    /**
     * @default 12
     */
    expandCollapseCueSize?: number;
    /**
     * @default 8
     */
    expandCollapseCueLineSize?: number;
    /**
     * @default undefined
     */
    expandCueImage?: string | false;
    /**
     * @default undefined
     */
    collapseCueImage?: string | false;
    /**
     * @default 1
     */
    expandCollapseCueSensitivity?: number;
    /**
     * @default edgeType
     */
    edgeTypeInfo?: string;
    /**
     * @default false
     */
    groupEdgesOfSameTypeOnCollapse?: boolean;
    /**
     * @default true
     */
    allowNestedEdgeCollapse?: boolean;
    /**
     * @default 999
     */
    zIndex?: number;
  }
  // add more if necessary when used
  interface CytoscapeExpandCollapse {
    expand: (nodes?: GraphElement[]) => void;
    collapseAll: (options?: unknown) => void;
    expandAll: (options?: unknown) => void;
    isExpandable: (node: GraphElement) => boolean;
    isCollapsible: (node: GraphElement) => boolean;
    collapse: (node?: GraphElement[]) => void;
  }
}

declare global {
  namespace cytoscape {
    interface Core {
      expandCollapse: (
        options?: expandCollapse.Options | 'get',
      ) => expandCollapse.CytoscapeExpandCollapse;
    }
  }
}
