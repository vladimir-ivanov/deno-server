import cytoscape = require('cytoscape');
import leaflet = require('leaflet');
import { Layer } from 'leaflet';
import { PresetLayoutOptions } from 'cytoscape';
// TODO remove if cy-leaflet stays internally
declare const leaf: cytoscape.Ext;
export = leaf;
export as namespace leaf;

declare namespace leaf {
  interface Options {
    container: HTMLElement;
    latitude: string;
    longitude: string;
    layout?: PresetLayoutOptions;
    elements?: any;
  }

  interface CytoscapeLeaf {
    L: typeof leaflet;
    map: leaflet.Map;
    cy: cytoscape.Core;
    defaultTileLayer: Layer;
    panMode: boolean;
    editMode: boolean;
    enablePanMode: () => void;
    enableEditMode: () => void;
    updateNodePositionFromCyEvent: () => void;
    fit: () => void;
    destroy: () => void;
  }
}

declare global {
  namespace cytoscape {
    interface Core {
      leaflet: (options?: leaf.Options) => leaf.CytoscapeLeaf;
    }
  }
}
