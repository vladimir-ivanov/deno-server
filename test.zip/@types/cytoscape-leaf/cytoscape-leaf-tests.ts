import cytoscape from 'cytoscape';
import * as leaflet from 'leaflet';
import * as leaf from 'cytoscape-leaf';

// eslint-disable-next-line @typescript-eslint/no-empty-function
const assert = (tag: boolean) => {};

cytoscape.use(leaf);

const leafOptions: leaf.Options = {
  latitude: 'latitude',
  longitude: 'longitude',
  container: document.getElementById('leaflet-map'),
};

const cy = cytoscape({
  container: document.getElementById('cy'),
});

const cyLeaf = cy.leaflet(leafOptions);
cyLeaf.fit();
cyLeaf.enableEditMode();
cyLeaf.defaultTileLayer;
cyLeaf.enablePanMode();
cyLeaf.destroy();

assert(typeof cyLeaf.map === typeof leaflet.Map);
assert(typeof cyLeaf.L === typeof leaflet);

cyLeaf.L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution:
    '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
});

cyLeaf.map.removeLayer(cyLeaf.defaultTileLayer);
