import {
  BaseIconButton,
  ButtonGroup,
} from '@trading-applications/ui-components';
// TODO - add to our icons set and replace
// eslint-disable-next-line import/no-extraneous-dependencies
import { ModeEdit, PanToolAlt } from '@mui/icons-material';
import { useEffect, useState } from 'react';
import { CytoscapeLeaf } from '../@types/cytoscape-leaf';

type CurrentMode = 'pan' | 'edit';

interface MapViewGraphControlsProps {
  cyLeaf?: CytoscapeLeaf;
}
export const MapViewGraphControls = ({ cyLeaf }: MapViewGraphControlsProps) => {
  const [currentMode, setCurrentMode] = useState<CurrentMode>('pan');

  useEffect(() => {
    setCurrentMode(cyLeaf?.panMode ? 'pan' : 'edit');
  }, [cyLeaf?.panMode]);

  const enablePanMode = () => {
    setCurrentMode('pan');
    cyLeaf?.enablePanMode();
  };

  const enableEditMode = () => {
    setCurrentMode('edit');
    cyLeaf?.enableEditMode();
  };

  return (
    <ButtonGroup sx={{ flexDirection: 'column' }}>
      <BaseIconButton
        isSelected={currentMode === 'pan'}
        onClick={enablePanMode}
        title="Zoom / pan map"
      >
        <PanToolAlt />
      </BaseIconButton>
      <BaseIconButton
        onClick={enableEditMode}
        isSelected={currentMode === 'edit'}
        title="Edit nodes on map"
      >
        <ModeEdit />
      </BaseIconButton>
    </ButtonGroup>
  );
};
