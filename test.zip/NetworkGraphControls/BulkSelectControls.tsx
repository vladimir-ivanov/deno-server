import {
  BaseIconButton,
  Box,
  ButtonGroup,
  ContainerColor,
} from '@trading-applications/ui-components';
// TODO - add to our icons set and replace
// eslint-disable-next-line import/no-extraneous-dependencies
import { GroupWork } from '@mui/icons-material';
import { DeleteIcon } from '@trading-applications/icons';
import { noop } from 'lodash';
import { useState } from 'react';
import { Autocomplete, AutoSaveForm, Form } from '@trading-applications/forms';
import { IconPopupButton } from '../FilterPopupButton';
import { getFilterOptions } from '../autocompleteFreeSoloOptions';

interface Props {
  parentsList?: string[];
  onParentAdd: (group: string) => void;
  onDelete?: () => void;
}
export const BulkElementsSelectionControls = ({
  parentsList = [],
  onParentAdd,
  onDelete = noop,
}: Props) => {
  const [group, setGroup] = useState('');

  const handleGroupConfirm = () => {
    if (group) {
      onParentAdd(group);
    }
  };
  return (
    <Box gap="8px" bgColor={ContainerColor.CORE_TWO} flexDirection="column">
      <ButtonGroup sx={{ flexDirection: 'column' }}>
        <IconPopupButton
          Icon={GroupWork}
          title="Add to group"
          onConfirm={handleGroupConfirm}
        >
          <Box justifyContent="flex-end" gap="4px">
            <Form<{ group: string }>
              dataCy="elementDetails"
              onSubmit={noop}
              defaultValues={{ group: '' }}
              mode="all"
            >
              <Autocomplete
                // @ts-expect-error
                freeSolo
                filterOptions={getFilterOptions()}
                options={parentsList}
                label="Group"
                name="group"
              />
              <AutoSaveForm onAutoSave={values => setGroup(values.group)} />
            </Form>
          </Box>
        </IconPopupButton>
        <BaseIconButton title="Delete selected" onClick={onDelete}>
          <DeleteIcon />
        </BaseIconButton>
      </ButtonGroup>
    </Box>
  );
};
