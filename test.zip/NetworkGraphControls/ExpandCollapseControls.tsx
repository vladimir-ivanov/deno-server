import {
  BaseIconButton,
  Box,
  ButtonGroup,
  ContainerColor,
} from '@trading-applications/ui-components';
// TODO - add to our icons set and replace
// eslint-disable-next-line import/no-extraneous-dependencies
import { AddBox, IndeterminateCheckBox } from '@mui/icons-material';
import { useCallback, useEffect, useRef } from 'react';
import { CytoscapeExpandCollapse } from '../@types/cytoscape-expand-collapse';
import { GraphElement } from '../NetworkGraph';
import { collapsedClass } from '../NetworkGraph/getStyles';
import { LayoutType } from '../types';
import { layoutConfigs } from '../NetworkGraphLayouts';

interface Props {
  cy?: cytoscape.Core;
  graphLayoutType: LayoutType;
  selectedNodes: GraphElement[];
}
export const ExpandCollapseControls = ({
  cy,
  selectedNodes,
  graphLayoutType,
}: Props) => {
  const cyExpandCollapse = useRef<CytoscapeExpandCollapse>();

  useEffect(() => {
    let instance = cyExpandCollapse.current;
    if (!cyExpandCollapse.current) {
      instance = cy?.expandCollapse({
        layoutBy: { name: graphLayoutType, ...layoutConfigs[graphLayoutType] },
        fisheye: false,
        animate: true,
        undoable: true,
      });
      cyExpandCollapse.current = instance;
    }
  }, [cy, graphLayoutType]);

  const handleExpandNodes = useCallback(() => {
    if (selectedNodes && selectedNodes.length > 0) {
      cyExpandCollapse.current?.expand(selectedNodes);
    } else {
      cyExpandCollapse.current?.expandAll();
    }
    cy?.nodes().forEach(element => {
      if (
        cyExpandCollapse.current?.isCollapsible(
          element as unknown as GraphElement,
        )
      ) {
        element.removeClass(collapsedClass);
      }
    });
  }, [cy, selectedNodes]);

  const handleCollapseNodes = useCallback(() => {
    if (selectedNodes && selectedNodes.length > 0) {
      cyExpandCollapse.current?.collapse(selectedNodes);
    } else {
      cyExpandCollapse.current?.collapseAll();
    }
    cy?.nodes().forEach(element => {
      if (
        cyExpandCollapse.current?.isExpandable(
          element as unknown as GraphElement,
        )
      ) {
        element.addClass(collapsedClass);
      }
    });
  }, [cy, selectedNodes]);

  return (
    <Box gap="8px" bgColor={ContainerColor.CORE_TWO} flexDirection="column">
      <ButtonGroup sx={{ flexDirection: 'column' }}>
        <BaseIconButton
          title="Expand all or selected nodes"
          onClick={handleExpandNodes}
        >
          <AddBox />
        </BaseIconButton>
        <BaseIconButton
          title="Collapse all or selected nodes"
          onClick={handleCollapseNodes}
        >
          <IndeterminateCheckBox />
        </BaseIconButton>
      </ButtonGroup>
    </Box>
  );
};
