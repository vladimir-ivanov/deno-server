import {
  BaseIconButton,
  Box,
  ContainerColor,
  Dropdown,
  DropdownOption,
} from '@trading-applications/ui-components';
import {
  CenterFocusWeakIcon,
  FitScreenIcon,
  PolylineIcon,
} from '@trading-applications/icons';
import { IconPopupButton } from '../FilterPopupButton';
import { NetworkGraphApi } from '../NetworkGraph';
import { LayoutType } from '../types';
import { Label } from '../Label';

const layoutTypes = Object.values(LayoutType);

interface GraphControlsProps {
  graphType: LayoutType;
  api?: NetworkGraphApi;
  onGraphTypeChange: (graphType: LayoutType) => void;
}

export const GraphControls = ({
  api,
  graphType,
  onGraphTypeChange,
}: GraphControlsProps) => {
  const handleGraphTypeChange = ({ target: { value } }) => {
    onGraphTypeChange(value as LayoutType);
  };

  return (
    <Box bgColor={ContainerColor.CORE_TWO} flexDirection="column">
      <IconPopupButton Icon={PolylineIcon} title="Layout">
        <Box justifyContent="flex-end" gap="4px">
          <Label name="graphType" label="Layout:" />
          <Dropdown
            style={{ minWidth: 100 }}
            size="small"
            placeholder="select type"
            id="graphType"
            value={graphType}
            onChange={handleGraphTypeChange}
          >
            {layoutTypes.map(option => (
              <DropdownOption key={option} value={option}>
                {option}
              </DropdownOption>
            ))}
          </Dropdown>
        </Box>
      </IconPopupButton>
      <BaseIconButton
        onClick={() => api?.centerSelected()}
        title="Center selection"
      >
        <CenterFocusWeakIcon />
      </BaseIconButton>
      <BaseIconButton onClick={() => api?.fit()} title="Fit to screen">
        <FitScreenIcon />
      </BaseIconButton>
    </Box>
  );
};
