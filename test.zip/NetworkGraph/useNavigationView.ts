import { useEffect } from 'react';
import cytoscape from 'cytoscape';
import navigator from 'cytoscape-navigator';
import { noop } from 'lodash';

cytoscape.use(navigator);

interface Props {
  cy?: cytoscape.Core;
  id: string;
}

export const useNavigationView = ({ cy, id }: Props) => {
  useEffect(() => {
    const instance =
      id && document.getElementById(id)
        ? cy?.navigator({ container: `#${id}` })
        : { destroy: noop };

    return () => {
      try {
        instance?.destroy();
        // eslint-disable-next-line no-empty
      } catch (e) {}
    };
  }, [cy, id]);
};
