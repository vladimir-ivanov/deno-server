import cytoscape from 'cytoscape';
import { useTheme } from '@trading-applications/ui-components';
import { useEffect } from 'react';
import { getStyles } from './getStyles';
import { NodeColors } from './types';

interface Props {
  cy?: cytoscape.Core;
  nodeColors?: NodeColors;
}

export const useThemedStyles = ({ cy, nodeColors }: Props) => {
  const theme = useTheme();

  useEffect(() => {
    if (nodeColors && theme && cy) {
      cy?.style(getStyles(nodeColors, theme));
    }
  }, [cy, nodeColors, theme]);
};
