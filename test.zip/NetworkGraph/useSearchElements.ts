import { useEffect } from 'react';
import cytoscape from 'cytoscape';
import { isNotMatchingTerm } from './isNotMatchingTerm';

interface Props {
  cy?: cytoscape.Core;
  searchTerm: string;
}

export const useSearchElements = ({ cy, searchTerm }: Props) => {
  useEffect(() => {
    cy?.elements().style({ opacity: 1 });
    const notFound = cy?.filter(element => {
      return (
        isNotMatchingTerm(element.data('name'), searchTerm) &&
        isNotMatchingTerm(element.data('description'), searchTerm)
      );
    });

    notFound?.style({ opacity: 0.2 });
  }, [cy, searchTerm]);
};
