import { CollectionReturnValue, EventObject } from 'cytoscape';
import { CytoscapeEvent } from '../types';
import { CytoscapeExpandCollapse } from '../@types/cytoscape-expand-collapse';
import { OnElementEdit, OnElementsInteract } from './types';
import './contextMenuStyles.scss';
import { collapsedClass } from './getStyles';

type CollapsibleCollection = Record<string, CollectionReturnValue>;

export interface CollapsedCollections {
  ancestors: CollapsibleCollection;
  successors: CollapsibleCollection;
}

interface ContextMenuConfigProps {
  onEdit: OnElementEdit;
  collections: CollapsedCollections;
  onDelete: OnElementsInteract;
  expandCollapse?: CytoscapeExpandCollapse;
}

const selector = 'node, edge';

export enum ToggleNodeItem {
  ExpandAncestors = 'expandAncestors',
  CollapseAncestors = 'collapseAncestors',
  ExpandGroup = 'expandGroup',
  CollapseGroup = 'collapseGroup',
  ExpandSuccessors = 'expandSuccessors',
  CollapseSuccessors = 'collapseSuccessors',
}

const handleExpand =
  (collections: CollapsedCollections, key: keyof CollapsedCollections) =>
  (event: EventObject) => {
    const element = event.target;

    if (collections[key][element.id()]) {
      element.removeClass(collapsedClass);
      collections[key][element.id()].restore();
    }
  };

const handleExpandGroup =
  (expandCollapse?: CytoscapeExpandCollapse) => (event: EventObject) => {
    const element = event.target;
    expandCollapse?.expand(element);
    element.removeClass(collapsedClass);
  };

const handleCollapseGroup =
  (expandCollapse?: CytoscapeExpandCollapse) => (event: EventObject) => {
    const element = event.target;
    expandCollapse?.collapse(element);
    element.addClass(collapsedClass);
  };

const handleCollapse =
  (collections: CollapsedCollections, key: keyof CollapsedCollections) =>
  (event: EventObject) => {
    const element = event.target;
    const collection =
      key === 'successors' ? element.successors() : element.ancestors();
    const targets = collection.targets();

    if (targets.length > 0) {
      element.addClass(collapsedClass);
      let cached = element.cy().collection();
      cached = cached.union(targets.remove());
      collections[key][element.id()] = cached;
    }
  };

export const getContextMenuOptions = ({
  collections,
  onEdit,
  onDelete,
  expandCollapse,
}: ContextMenuConfigProps) => ({
  evtType: CytoscapeEvent.CotnextTap,
  menuItems: [
    {
      id: ToggleNodeItem.ExpandSuccessors,
      content: 'Expand successors',
      selector: 'node',
      onClickFunction: handleExpand(collections, 'successors'),
      hasTrailingDivider: true,
    },
    {
      id: ToggleNodeItem.CollapseSuccessors,
      content: 'Collapse successors',
      selector: 'node',
      onClickFunction: handleCollapse(collections, 'successors'),
      hasTrailingDivider: true,
    },
    {
      id: ToggleNodeItem.ExpandAncestors,
      content: 'Expand ancestors',
      selector: 'node',
      onClickFunction: handleExpand(collections, 'ancestors'),
      hasTrailingDivider: true,
    },
    {
      id: ToggleNodeItem.CollapseAncestors,
      content: 'Collapse ancestors',
      selector: 'node',
      onClickFunction: handleCollapse(collections, 'successors'),
      hasTrailingDivider: true,
    },
    {
      id: ToggleNodeItem.ExpandGroup,
      content: 'Expand group',
      selector: 'node',
      onClickFunction: handleExpandGroup(expandCollapse),
      hasTrailingDivider: true,
    },
    {
      id: ToggleNodeItem.CollapseGroup,
      content: 'Collapse group',
      selector: 'node',
      onClickFunction: handleCollapseGroup(expandCollapse),
      hasTrailingDivider: true,
    },
    {
      id: 'editElement',
      content: 'Edit',
      selector,
      onClickFunction: event => {
        onEdit(event.target);
      },
      hasTrailingDivider: true,
    },
    {
      id: 'deleteElement',
      content: 'Delete',
      selector,
      onClickFunction: ({ target: element }) => {
        onDelete([element]);
      },
    },
  ],
  menuItemClasses: ['element-menu-item', 'element-menu-item:hover'],
  contextMenuClasses: ['element-context-menu'],
});
