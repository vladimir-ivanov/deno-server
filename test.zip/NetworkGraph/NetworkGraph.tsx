import cytoscape, { ElementDefinition } from 'cytoscape';
import {
  Box,
  FeedbackSeverity,
  MiniFeedback,
} from '@trading-applications/ui-components';
import { useState } from 'react';
import expandCollapse from 'cytoscape-expand-collapse';
import { XYPosition } from '../../api';
import { LayoutType, MapPosition } from '../types';
import { CytoscapeLeaf } from '../@types/cytoscape-leaf';
import { MapGraphLayout } from '../NetworkGraphLayouts';
import { useDrawMode } from './useDrawMode';
import {
  NodeColors,
  OnElementEdit,
  OnElementInteract,
  OnElementsInteract,
} from './types';
import { useTooltip } from './useTooltip';
import { useGraphEvents } from './useGraphEvents';
import { useLockNode } from './useLockNode';
import { useRefreshLayout } from './useRefreshLayout';
import { useThemedStyles } from './useThemedStyles';
import { useInit } from './useInit';
import { useSearchElements } from './useSearchElements';
import { BirdEyeView } from './BirdEyeView';
import { useResize } from './useResize';
import { useContextMenu } from './useContextMenu';
import { usePresetLayoutEditNodeCoordinates } from './usePresetLayoutEditNodeCoordinates';

cytoscape.use(expandCollapse);

interface NetworkGraphProps {
  data: ElementDefinition[];
  nodeColors?: NodeColors;
  id: string;
  isDrawModeOn: boolean;
  layoutType: LayoutType;
  onElementAdd: OnElementInteract;
  onElementDoubleClick: OnElementInteract;
  onElementEdit: OnElementEdit;
  onNodeUpdateMapCoordinates: (position: MapPosition) => void;
  onNodeUpdateXYPosition: (position: XYPosition) => void;
  onElementsSelect: OnElementsInteract;
  onElementsDelete: OnElementsInteract;
  searchTerm: string;
}

export const NetworkGraph = ({
  data,
  id,
  isDrawModeOn,
  layoutType,
  nodeColors,
  onElementAdd,
  onElementDoubleClick,
  onElementEdit,
  onElementsSelect,
  onElementsDelete,
  onNodeUpdateMapCoordinates,
  onNodeUpdateXYPosition,
  searchTerm,
}: NetworkGraphProps) => {
  const { cy, elRef } = useInit(id);
  const [cyLeaf, setCyLeaf] = useState<CytoscapeLeaf>();
  useThemedStyles({ cy, nodeColors });
  useSearchElements({ cy, searchTerm });
  useDrawMode({ cy, isDrawModeOn, onElementAdd, cyLeaf, layoutType });
  useTooltip({ cy, isDisabled: isDrawModeOn });
  useGraphEvents({
    cy,
    onElementsDelete,
    onElementsSelect,
    onElementDoubleClick,
  });
  useLockNode({ cy });
  useResize({ cy, elRef: elRef.current });
  usePresetLayoutEditNodeCoordinates({
    cy,
    isEnabled: layoutType === LayoutType.Preset,
    onNodeDragEnd: onNodeUpdateXYPosition,
  });
  useRefreshLayout({
    cy,
    layoutType,
    data,
    isDrawModeOn,
    isDisabled: layoutType === LayoutType.Map,
  });

  useContextMenu({
    cy,
    onDelete: onElementsDelete,
    onEdit: onElementEdit,
  });

  return (
    <Box position="relative" flex={1}>
      {layoutType === LayoutType.Map && (
        <MapGraphLayout
          id={id}
          data={data}
          cy={cy}
          onNodeDragEnd={onNodeUpdateMapCoordinates}
          onMapInitialized={setCyLeaf}
        />
      )}
      <Box
        padding="16px"
        ref={elRef}
        zIndex={2}
        id={id}
        position="absolute"
        top={0}
        left={0}
        right={0}
        bottom={0}
      >
        {isDrawModeOn && (
          <Box position="absolute" left="16px">
            <MiniFeedback severity={FeedbackSeverity.INFO}>
              Add node or edge enabled
            </MiniFeedback>
          </Box>
        )}
        <BirdEyeView cy={cy} />
      </Box>
    </Box>
  );
};
