import ReactMarkdown from 'react-markdown';
import { Text, TextVariant } from '@trading-applications/ui-components';

// TODO wire in light theme
export const tooltipStyles =
  'background-color: #364050FF;color: #fff;text-align: left; padding: 8px; border-radius: 4px; min-width: 100px; max-width: 500px; z-index:10000';

export const Tooltip = ({ name, type, description }) => (
  <div>
    {name && <Text textVariant={TextVariant.H3}>{name}</Text>}
    {type && <Text textVariant={TextVariant.H4}>{type}</Text>}
    {description && <ReactMarkdown>{description}</ReactMarkdown>}
  </div>
);
