import { useEffect, useRef } from 'react';
import cytoscape from 'cytoscape';

interface Props {
  cy?: cytoscape.Core;
  elRef?: HTMLElement;
}

export const useResize = ({ cy, elRef }: Props) => {
  const resizeObserver = useRef(
    new ResizeObserver(() => {
      cy?.resize();
    }),
  );

  useEffect(() => {
    const observer = resizeObserver.current;

    if (elRef) {
      observer.observe(elRef);
    }

    return () => {
      if (elRef) {
        observer.unobserve(elRef);
      }
    };
  }, [cy, elRef]);
};
