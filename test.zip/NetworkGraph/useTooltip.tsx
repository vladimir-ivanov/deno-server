import { useEffect } from 'react';
import cytoscape from 'cytoscape';
import { renderToString } from 'react-dom/server';
import popper from 'cytoscape-popper';
import { Tooltip, tooltipStyles } from './Tooltip';

cytoscape.use(popper);

const selector = 'node, edge';
const cancelEvents = ['cxttap', 'mouseout', 'mousedown'];

interface UseDrawModeProps {
  cy?: cytoscape.Core;
  isDisabled: boolean;
}

export const useTooltip = ({ cy, isDisabled }: UseDrawModeProps) => {
  useEffect(() => {
    let isOn = false;
    const tips = document.createElement('div');
    const mouseOverEvent = event => {
      isOn = true;
      const target = event.target;

      target.popperRef = target.popper({
        content: () => {
          const { name, description, type } = target.data();

          tips.innerHTML = renderToString(
            <Tooltip name={name} description={description} type={type} />,
          );
          tips.setAttribute('style', tooltipStyles);
          document.body.appendChild(tips);
          return tips;
        },
        popper: {
          placement: 'bottom-end',
          removeOnDestroy: true,
        },
      });
    };

    const cancelMouseover = _ => {
      if (isOn) {
        document.body.removeChild(tips);
        isOn = false;
      }
    };

    if (cy && !isDisabled) {
      cy.on('mouseover', selector, mouseOverEvent);

      cancelEvents.forEach(event => {
        cy.on(event, selector, cancelMouseover);
      });
    } else {
      cy?.off('mouseover', selector, mouseOverEvent);
      cancelEvents.forEach(event => {
        cy?.off(event, selector, cancelMouseover);
      });
    }

    return () => {
      cy?.off('mouseover', selector, mouseOverEvent);
      cancelEvents.forEach(event => {
        cy?.off(event, selector, cancelMouseover);
      });
    };
  }, [cy, isDisabled]);
};
