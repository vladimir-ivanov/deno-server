export const isNotMatchingTerm = (element: string, term: string) =>
  (element || '').toLowerCase().indexOf(term.toLowerCase()) === -1;
