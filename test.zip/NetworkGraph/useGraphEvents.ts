import { useCallback, useEffect, useMemo } from 'react';
import cytoscape from 'cytoscape';
import { debounce } from 'lodash';
import { CytoscapeEvent } from '../types';
import { GraphElement, OnElementInteract, OnElementsInteract } from './types';

const nodeEdge = 'node, edge';

const getSelected = (cy: cytoscape.Core) =>
  cy
    .elements()
    .filter(element => element.selected()) as unknown as GraphElement[];

interface Props {
  cy?: cytoscape.Core;
  onElementDoubleClick: OnElementInteract;
  onElementsDelete: OnElementsInteract;
  onElementsSelect: OnElementsInteract;
}

export const useGraphEvents = ({
  cy,
  onElementDoubleClick,
  onElementsDelete,
  onElementsSelect,
}: Props) => {
  useEffect(() => {
    //todo this can be moved closer to its usage and keep on ElementsSelect only
    const keyupListener = event => {
      if (event.key === 'Delete' && cy) {
        onElementsDelete(getSelected(cy));
      }
    };

    window.addEventListener('keyup', keyupListener);

    return () => {
      window.removeEventListener('keyup', keyupListener);
    };
  }, [cy, onElementsDelete]);

  //debounce is needed as the select event triggers on each selection of a node
  const handleSelectionChange = useMemo(
    () =>
      debounce(() => {
        if (cy) {
          onElementsSelect(getSelected(cy));
        }
      }, 300),
    [cy, onElementsSelect],
  );

  const handleDblClick = useCallback(
    event => {
      if (cy) {
        onElementDoubleClick(event.target);
      }
    },
    [cy, onElementDoubleClick],
  );

  useEffect(() => {
    cy?.on(CytoscapeEvent.Select, nodeEdge, handleSelectionChange);
    cy?.on(CytoscapeEvent.Unselect, nodeEdge, handleSelectionChange);
    cy?.on(CytoscapeEvent.DoubleClick, nodeEdge, handleDblClick);

    return () => {
      cy?.off(CytoscapeEvent.Select, nodeEdge, handleSelectionChange);
      cy?.off(CytoscapeEvent.Unselect, nodeEdge, handleSelectionChange);
      cy?.off(CytoscapeEvent.DoubleClick, nodeEdge, handleDblClick);
    };
  }, [cy, handleDblClick, handleSelectionChange]);
};
