import { useCallback, useEffect, useRef } from 'react';
import cytoscape from 'cytoscape';
import { log } from '@trading-applications/logger';
import { useAtom } from 'jotai';
import { NetworkDataDefinition, NetworkElement } from '../../api';
import { CytoscapeEvent } from '../types';
import { networkGraphApiAtom } from './networkGraphApiAtom';

const fit = (cy?: cytoscape.Core) => {
  if (cy) {
    cy.emit(CytoscapeEvent.Fit);
    cy.fit();
  }
};

const defaultCytscapeConfig = {
  wheelSensitivity: 0.1,
  elements: [],
  layout: {
    name: 'circle',
    animate: true,
  },
  pan: { x: 0, y: 0 },
};

export const useInit = (graphId: string) => {
  const elRef = useRef<HTMLElement>();
  const cy = useRef<cytoscape.Core>();
  const [, setApi] = useAtom(networkGraphApiAtom);

  const centerSelected = useCallback(() => {
    const selected = cy.current
      ?.elements()
      .filter(element => element.selected());

    cy.current?.center(selected);
    cy.current?.emit(CytoscapeEvent.Center, [selected]);
  }, []);

  const selectElement = useCallback((element: NetworkDataDefinition) => {
    const found = cy.current?.filter(el => el.id() === element.id);

    if (found && !found?.selected()) {
      cy.current?.elements().unselect();
      found?.select();
    }
  }, []);

  const updateElements = useCallback((elements: NetworkElement[]) => {
    if (elements && elements.length > 0) {
      const { id, dataVisualisationId } = elements[0].data;
      if (dataVisualisationId) {
        const nodeDataVisMatch = cy.current?.getElementById(
          dataVisualisationId as string,
        );
        nodeDataVisMatch?.data({
          ...nodeDataVisMatch.data(),
          ...elements[0].data,
        });
      }

      const node = cy.current?.getElementById(id);
      node?.data({ ...node.data(), ...elements[0].data });
    }
  }, []);

  useEffect(() => {
    cy.current = cytoscape({
      container: elRef.current,
      ...defaultCytscapeConfig,
    });

    cy.current?.ready(() => {
      setApi(record => ({
        ...record,
        [graphId]: {
          cy: cy.current,
          fit: () => fit(cy.current),
          centerSelected,
          selectElement,
          updateElements,
        },
      }));
      log('cytoscape graph ready');
    });
  }, [centerSelected, graphId, selectElement, setApi, updateElements]);

  return { cy: cy.current, elRef };
};
