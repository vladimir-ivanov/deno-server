import { DesignColors, Theme } from '@trading-applications/ui-components';
import { noLabelClass, outlinedLabelClass } from '../NetworkGraphLayouts';
import { parentType } from '../../api';

export const collapsedClass = 'isCollapsed';

export const getNodeTypeColor = (
  colorMap: Record<string, string> | undefined,
  type: string,
) => {
  if (type === parentType) {
    return '#4B5971';
  }

  return colorMap
    ? colorMap[type] || DesignColors.$dataVizTwoBase
    : DesignColors.$dataVizTwoBase;
};
export const getStyles = (
  colorNodeMap: Record<string, string>,
  theme: Theme,
) => {
  const edgeColor = () => DesignColors.$dataVizFour2;
  const edgeWidth = element =>
    element.data().weight ? parseInt(element.data().weight, 10) + 1 : 1;

  const label = 'data(name)';
  const nodeRadius = '24px';

  return [
    {
      selector: 'node',
      style: {
        'font-size': '12px',
        'background-color': element =>
          getNodeTypeColor(colorNodeMap, element.data().type),
        'border-color': element =>
          getNodeTypeColor(colorNodeMap, element.data().type),
        color: theme?.name === 'LIGHT' ? 'black' : 'white',
        width: nodeRadius,
        height: nodeRadius,
        label,
      },
    },
    {
      selector: ':parent',
      style: {
        'background-opacity': 0.15,
        'border-color': '#4B5971',
        'border-width': '1px',
      },
    },
    {
      selector: `node.${outlinedLabelClass}`,
      style: {
        color: theme?.name === 'LIGHT' ? 'white' : 'black',
        'text-background-opacity': 0.7,
        'text-background-color': theme?.name === 'LIGHT' ? 'grey' : 'white',
        width: nodeRadius,
        height: nodeRadius,
        label,
      },
    },
    {
      selector: 'node:selected',
      style: {
        'border-width': '16px',
        'border-style': 'double',
        'border-color': element =>
          getNodeTypeColor(colorNodeMap, element.data().type),
      },
    },
    {
      selector: `node.${noLabelClass}`,
      style: {
        label: '',
      },
    },
    {
      selector: 'edge:selected',
      style: {
        'border-width': '24px',
        'border-color': DesignColors.$Accent1,
      },
    },
    {
      selector: `node.${collapsedClass}`,
      style: {
        'border-width': '12px',
        'border-color': theme?.name === 'LIGHT' ? 'black' : 'white',
        'border-opacity': 0.2,
      },
    },
    {
      selector: 'edge',
      style: {
        opacity: 0.5,
        width: edgeWidth,
        'line-color': edgeColor,
        'target-arrow-color': edgeColor,
        'target-arrow-shape': 'triangle',
        'curve-style': 'bezier',
      },
    },
    {
      selector: 'edge.highlighted',
      style: {
        'line-color': DesignColors.$dataVizOne2,
      },
    },
    {
      selector: 'node.highlighted',
      style: {
        'border-width': '6px',
        'border-color': DesignColors.$Accent1,
      },
    },
    {
      selector: '.highlighted',
      style: {
        'border-width': '6px',
        'border-color': DesignColors.$Accent1,
      },
    },
    {
      selector: '.start',
      style: {
        'border-width': '15px!important',
      },
    },
    {
      selector: '.end',
      style: {
        'border-width': '15px!important',
      },
    },
  ];
};
