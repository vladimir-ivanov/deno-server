import { Meta } from '@storybook/react';
import { Box } from '@trading-applications/ui-components';
import './layoutConfigs';
import { QueryElementTuple, remapQueryNodesAndEdges } from '../../api';
import { LayoutType } from '../types';
import { NetworkGraph } from './NetworkGraph';
import data from './testNetworkData.json';

export default {
  title: 'NetworkGraph / NetworkGraph',
  component: NetworkGraph,
  args: {
    id: 'graphId',
    nodeColors: {
      Enterprise: 'red',
      Fuel: 'yellow',
    },
    data: remapQueryNodesAndEdges(
      data.results as unknown as QueryElementTuple[],
    ),
    layoutType: LayoutType.D3Force,
  },
} as Meta<typeof NetworkGraph>;

const Template = args => (
  <Box height="700px" width="100%" border={5}>
    <NetworkGraph {...args} />
  </Box>
);

export const Basic = Template.bind({});
