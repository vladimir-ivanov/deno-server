import { useEffect } from 'react';
import cytoscape, { ElementDefinition, Layouts } from 'cytoscape';
import { LayoutType } from '../types';
import { layoutConfigs } from '../NetworkGraphLayouts';

interface Props {
  cy?: cytoscape.Core;
  layoutType: LayoutType;
  isDisabled: boolean;
  isDrawModeOn: boolean;
  data: ElementDefinition[];
}

export const useRefreshLayout = ({
  cy,
  layoutType,
  isDisabled,
  isDrawModeOn,
  data,
}: Props) => {
  useEffect(() => {
    let layoutRef: Layouts | undefined;

    if (!isDisabled && !isDrawModeOn && data) {
      cy?.elements().remove();
      cy?.add(data);
      layoutRef = cy?.makeLayout({
        name: layoutType,
        ...(layoutConfigs[layoutType] || {}),
      });
      layoutRef?.run()?.promiseOn('layoutstop');
    }
    return () => {
      layoutRef?.removeAllListeners();
      layoutRef?.off('add');
      layoutRef?.stop();
    };
  }, [isDrawModeOn, layoutType, data, isDisabled, cy]);
};
