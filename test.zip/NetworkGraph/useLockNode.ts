import { useCallback, useEffect } from 'react';
import cytoscape, { EventHandler } from 'cytoscape';

const lockCallback: EventHandler = event => {
  event.target.lock();
};

interface Props {
  cy?: cytoscape.Core;
}

export const useLockNode = ({ cy }: Props) => {
  const unLockCallback = useCallback(() => {
    cy?.elements().unlock();
  }, [cy]);

  useEffect(() => {
    cy?.ready(() => {
      cy?.on('mousedown', 'node', unLockCallback);
      cy?.on('mouseup', 'node', lockCallback);
    });

    return () => {
      cy?.off('mousedown', 'node', unLockCallback);
      cy?.off('mouseup', 'node', lockCallback);
    };
  }, [cy, unLockCallback]);
};
