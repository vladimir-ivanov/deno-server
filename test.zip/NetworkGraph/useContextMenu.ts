import { useEffect, useRef } from 'react';
import cytoscape from 'cytoscape';
import contextMenus from 'cytoscape-context-menus';
import 'cytoscape-context-menus/cytoscape-context-menus.css';
import { CytoscapeEvent } from '../types';
import { CytoscapeExpandCollapse } from '../@types/cytoscape-expand-collapse';
import { OnElementEdit, OnElementsInteract } from './types';
import {
  CollapsedCollections,
  getContextMenuOptions,
  ToggleNodeItem,
} from './getContextMenuOptions';
import { collapsedClass } from './getStyles';

cytoscape.use(contextMenus);

const contextTapHandler =
  (
    collections: CollapsedCollections,
    menuHandler?: contextMenus.ContextMenu,
    expandCollapse?: CytoscapeExpandCollapse,
  ) =>
  event => {
    Object.values(ToggleNodeItem).forEach(item =>
      menuHandler?.hideMenuItem(item),
    );

    const element = event.target;
    if (!element || !element.id) {
      return;
    }
    const id = element.id();
    const successors = element.successors().targets();
    const ancestors = element.ancestors();
    const cachedAncestors = collections.ancestors[id];
    const cachedSuccessors = collections.successors[id];

    if (expandCollapse?.isExpandable(element)) {
      menuHandler?.showMenuItem(ToggleNodeItem.ExpandGroup);
    }

    if (expandCollapse?.isCollapsible(element)) {
      menuHandler?.showMenuItem(ToggleNodeItem.CollapseGroup);
    }

    if (!event.target.hasClass(collapsedClass)) {
      if (successors.length > 0) {
        menuHandler?.showMenuItem(ToggleNodeItem.CollapseSuccessors);
      }
      if (ancestors.length > 0) {
        menuHandler?.showMenuItem(ToggleNodeItem.CollapseAncestors);
      }
    }

    if (element.hasClass(collapsedClass)) {
      if (cachedAncestors) {
        menuHandler?.showMenuItem(ToggleNodeItem.ExpandAncestors);
      }
      if (cachedSuccessors) {
        menuHandler?.showMenuItem(ToggleNodeItem.ExpandSuccessors);
      }
    }
  };

interface Props {
  cy?: cytoscape.Core;
  onEdit: OnElementEdit;
  onDelete: OnElementsInteract;
}

export const useContextMenu = ({ cy, onEdit, onDelete }: Props) => {
  const menuHandler = useRef<contextMenus.ContextMenu>();
  const collections = useRef<CollapsedCollections>({
    ancestors: {},
    successors: {},
  });

  useEffect(() => {
    menuHandler.current = cy?.contextMenus(
      getContextMenuOptions({
        collections: collections.current,
        onEdit,
        onDelete,
        expandCollapse: cy?.expandCollapse('get'),
      }),
    );

    const handler = contextTapHandler(
      collections.current,
      menuHandler.current,
      cy?.expandCollapse('get'),
    );

    cy?.on(CytoscapeEvent.CotnextTap, handler);

    return () => {
      menuHandler.current?.destroy();
      cy?.off(CytoscapeEvent.CotnextTap, handler);
    };
  }, [cy, onDelete, onEdit]);
};
