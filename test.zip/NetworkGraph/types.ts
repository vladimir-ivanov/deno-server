import {
  EdgeCollection,
  NodeCollection,
  Singular,
  SingularData,
} from 'cytoscape';

export type NodeColors = Record<string, string>;

export type GraphElement = EdgeCollection &
  NodeCollection &
  Singular &
  SingularData;

export type OnElementEdit = (element: GraphElement) => void;
export type OnElementsInteract = (elements: GraphElement[]) => void;
export type OnElementInteract = (props: GraphElement) => void;
