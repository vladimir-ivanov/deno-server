import { useCallback, useEffect, useRef } from 'react';
import cytoscape from 'cytoscape';
import edgehandles, { EdgeHandlesInstance } from 'cytoscape-edgehandles';
import { CytoscapeEvent, LayoutType } from '../types';
import { CytoscapeLeaf } from '../@types/cytoscape-leaf';
import { syncLatLng } from '../NetworkGraphLayouts';
import { GraphElement, OnElementInteract } from './types';
import { getEdgeHandlesConfig } from './getEdgeHandlesConfig';

cytoscape.use(edgehandles);

let nodeCounter = 1;
const circleRadius = '24px';

interface UseDrawModeProps {
  cy?: cytoscape.Core;
  isDrawModeOn: boolean;
  onElementAdd: OnElementInteract;
  cyLeaf?: CytoscapeLeaf;
  layoutType: LayoutType;
}

export const useDrawMode = ({
  cy,
  cyLeaf,
  isDrawModeOn,
  onElementAdd,
  layoutType,
}: UseDrawModeProps) => {
  const edgeHandler = useRef<EdgeHandlesInstance>();
  const handleTap = useCallback(
    event => {
      const name = `Node ${nodeCounter++}`;
      const renderedPosition = {
        x: event.renderedPosition.x,
        y: event.renderedPosition.y,
      };

      const coordinates =
        cyLeaf && layoutType === LayoutType.Map
          ? syncLatLng(renderedPosition, cyLeaf.map)
          : {};

      const element = cy?.add([
        {
          data: {
            name,
            ...coordinates,
            ...(layoutType === LayoutType.Preset ? renderedPosition : {}),
          },
          style: {
            width: circleRadius,
            height: circleRadius,
          },
          group: 'nodes',
          renderedPosition,
        },
      ]);

      element?.data('dbInsertId', element?.id());

      onElementAdd(element as GraphElement);
    },
    [cy, cyLeaf, layoutType, onElementAdd],
  );

  useEffect(() => {
    if (cy) {
      edgeHandler.current = cy.edgehandles(getEdgeHandlesConfig(onElementAdd));
    }
  }, [cy, onElementAdd]);

  useEffect(() => {
    if (!cy) {
      return;
    }

    if (isDrawModeOn) {
      if (cyLeaf) {
        // not needed, triggers unnecessary re renders AND messes up edge handler!
        cyLeaf.cy.off(CytoscapeEvent.Add, cyLeaf.updateNodePositionFromCyEvent);
      }
      cyLeaf?.enableEditMode();
      edgeHandler.current?.enableDrawMode();
      cy.on(CytoscapeEvent.Tap, handleTap);
    } else {
      if (cyLeaf) {
        cyLeaf.cy.on(CytoscapeEvent.Add, cyLeaf.updateNodePositionFromCyEvent);

        cyLeaf?.enablePanMode();
      }
      edgeHandler.current?.disableDrawMode();
      cy.off(CytoscapeEvent.Tap, handleTap);

      if (!cyLeaf) {
        cy.zoomingEnabled(true);
        cy.panningEnabled(true);
        cy.boxSelectionEnabled(true);
        cy.autoungrabify(false);
      }

      cy.forceRender();
    }

    return () => {
      if (cyLeaf) {
        cyLeaf.cy.on(CytoscapeEvent.Add, cyLeaf.updateNodePositionFromCyEvent);
      }
      cy?.off(CytoscapeEvent.Tap, handleTap);
      cy?.forceRender();
      edgeHandler.current?.destroy();
    };
  }, [cy, cyLeaf, isDrawModeOn, onElementAdd, handleTap]);
};
