import { useAtom } from 'jotai';
import { networkGraphApiAtom } from './networkGraphApiAtom';

export const useNetworkGraphApi = (id: string) => {
  const [api] = useAtom(networkGraphApiAtom);
  return api[id];
};
