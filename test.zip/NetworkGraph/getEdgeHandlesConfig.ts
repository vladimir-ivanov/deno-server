import { OnElementInteract } from './types';

const edgeCounter = 1;

export const getEdgeHandlesConfig = (onElementAdd: OnElementInteract) => ({
  canConnect: (sourceNode, targetNode) => !sourceNode.same(targetNode),
  edgeParams: (sourceNode, targetNode) => {
    const tempEdgeId = Math.random() * Date.now();
    const name = `Edge ${edgeCounter}`;
    const event = 'mouseup';
    const listener = () => {
      if (targetNode) {
        setTimeout(() => {
          const element = targetNode
            .cy()
            .elements()
            .filter(el => el.data('tempEdgeId') === tempEdgeId)[0];

          const sourceId = sourceNode.data('dbInsertId') || sourceNode.id();
          const targetId = targetNode.data('dbInsertId') || targetNode.id();

          element.data('sourceId', sourceId);
          element.data('targetId', targetId);
          onElementAdd(element);
        }, 300);
      }
      removeEventListener(event, listener);
    };
    addEventListener(event, listener);
    return { data: { weight: 1, name, tempEdgeId } };
  },
});
