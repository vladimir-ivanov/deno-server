import { useEffect } from 'react';
import cytoscape from 'cytoscape';
import { XYPosition } from '../../api';
import { CytoscapeEvent } from '../types';

interface Props {
  cy?: cytoscape.Core;
  isEnabled: boolean;
  onNodeDragEnd: (point: XYPosition) => void;
}

export const usePresetLayoutEditNodeCoordinates = ({
  cy,
  isEnabled,
  onNodeDragEnd,
}: Props) => {
  useEffect(() => {
    const dragHandler = event => {
      if (isEnabled) {
        const node = event.target;
        onNodeDragEnd({
          id: node.data('id'),
          ...node.position(),
        });
      }
    };

    cy?.on(CytoscapeEvent.Dragfree, 'node', dragHandler);

    return () => {
      cy?.off(CytoscapeEvent.Dragfree, 'node', dragHandler);
    };
  }, [cy, isEnabled, onNodeDragEnd]);
};
