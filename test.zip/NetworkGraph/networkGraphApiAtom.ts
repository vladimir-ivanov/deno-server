import { atom } from 'jotai';
import { NetworkDataDefinition, NetworkElement } from '../../api';

const getError = (id: string) =>
  // eslint-disable-next-line no-console
  console.error(
    `you have attempted to call a network graph api method for graph with id: "${id}" before it has been initialized.`,
  );

export interface NetworkGraphApi {
  fit: () => void;
  cy?: cytoscape.Core;
  centerSelected: () => void;
  selectElement: (element: NetworkDataDefinition) => void;
  updateElements: (elements: NetworkElement[]) => void;
}

const record = {} as Record<string, NetworkGraphApi>;
const proxy = new Proxy<Record<string, NetworkGraphApi>>(record, {
  get(target, prop: string, receiver) {
    const value = Reflect.get(target, prop, receiver);
    const noop = () => getError(prop);

    if (!value) {
      return {
        cy: undefined,
        fit: noop,
        centerSelected: noop,
        selectElement: noop,
        updateElements: noop,
      } as NetworkGraphApi;
    }
    return typeof value === 'function' ? value.bind(target) : value;
  },
});

export const networkGraphApiAtom = atom(proxy);
