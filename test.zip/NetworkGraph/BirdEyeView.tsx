import { Box, ContainerColor } from '@trading-applications/ui-components';
import cytoscape from 'cytoscape';
import 'cytoscape-navigator/cytoscape.js-navigator.css';
import { useNavigationView } from './useNavigationView';

interface NavigationViewProps {
  cy?: cytoscape.Core;
  width?: number;
  height?: number;
}

export const BirdEyeView = ({
  cy,
  width = 250,
  height = 200,
}: NavigationViewProps) => {
  const navigatorViewId = 'navigatorView';
  useNavigationView({ cy, id: navigatorViewId });

  return (
    <Box
      bgColor={ContainerColor.MAIN}
      id={navigatorViewId}
      position="absolute"
      bottom={0}
      right={0}
      width={width}
      height={height}
      overflow="hidden"
      border="1px solid grey"
      zIndex={104}
    />
  );
};
